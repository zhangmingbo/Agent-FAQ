/**
 * LLM 提示词注册表（运营配置，管理后台可编辑）
 *
 * 设计原则（松耦合：运营配置与底层逻辑分离）：
 *   - 所有 LLM 调用点的提示词集中在此定义，默认值内置兜底（不配置也能跑）
 *   - 运营在管理后台「LLM 智能层」页面覆盖提示词，存 sys_config（键 llm_prompt.<环节>.<部分>）
 *   - 底层逻辑只负责"取模板 + 填占位符 + 调 LLM"，不写业务文案
 *
 * 用法：
 *   await initPrompts()           启动时加载（幂等）
 *   get('extract_slots.user', {taskName, slotDesc, text})  取模板并填充占位符
 *   getAll()                      返回全部调用点（含默认值/是否自定义/占位符说明）
 *   updatePrompts({key: value})   保存自定义提示词（空值=恢复默认）
 */

import * as configRepo from '../repositories/configRepo.js'

/**
 * 提示词定义表
 * key: 环节.部分
 *   default:    内置默认值（兜底）
 *   name:       管理后台显示名
 *   desc:       用途说明
 *   placeholders: 模板占位符（管理后台提示用）
 */
const PROMPT_DEFS = {
  'extract_slots.system': {
    name: '槽位提取 · 系统提示词',
    desc: '指导 LLM 如何从用户话术中提取槽位（含枚举归一化、不编造约束）',
    default: '你是客服信息提取助手。只根据用户话术提取指定字段，返回严格 JSON 对象，不要任何解释、前后缀或 markdown 代码块。提取不到的字段不要出现。如果用户输入中没有明确提供某个字段的信息，绝对不要编造，也不要重复用户输入的整句话作为字段值——该字段直接省略。枚举字段（可选值已列出）请把用户说法映射到最接近的选项，无法归类时选"其他"，绝不编造选项之外的值。',
  },
  'extract_slots.user': {
    name: '槽位提取 · 用户模板',
    desc: '每次提取时发给 LLM 的用户消息模板，{占位符} 由系统填充',
    placeholders: ['taskName', 'examples', 'slotDesc', 'filledDesc', 'text'],
    default: '任务：{taskName}{examples}\n需提取字段：{slotDesc}\n{filledDesc}用户输入："{text}"\n请返回 JSON：',
  },
  'judge_trigger.system': {
    name: '触发判定 · 系统提示词',
    desc: '判断用户输入是否意图办理某个业务任务（而非咨询/闲聊）',
    default: '你是客服意图判定器。判断用户输入是否意图办理某个业务任务（而非单纯咨询/闲聊）。只返回任务 code 或 null，不要任何其他文字。',
  },
  'judge_trigger.user': {
    name: '触发判定 · 用户模板',
    placeholders: ['taskDesc', 'text'],
    default: '可选任务：\n{taskDesc}\n用户输入："{text}"\n请返回触发的任务 code（未触发返回 null）：',
  },
  'llm_rerank.system': {
    name: 'FAQ 意图重排 · 系统提示词',
    desc: 'FAQ 置信度低时，从 top-5 候选意图中选出最符合用户问题的',
    default: '你是客服意图判定器。从候选列表中选出最符合用户问题的那个，只返回数字序号，不要其他文字。',
  },
  'llm_rerank.user': {
    name: 'FAQ 意图重排 · 用户模板',
    placeholders: ['list', 'text'],
    default: '候选：\n{list}\n用户问题："{text}"\n请返回序号：',
  },
  'faq_answer.system': {
    name: 'FAQ 兜底回答 · 系统提示词',
    desc: '知识库未命中时，作为智能客服生成回答',
    default: '你是一个智能客服助手，请根据用户的问题提供准确、友好的回答。',
  },
  'meaningless.system': {
    name: '无意义判断 · 系统提示词',
    desc: '判断用户输入是否是有意义的咨询问题（llm 无意义模式启用时）',
    default: '你是一个对话质量判断器。判断用户输入是否是有意义的咨询问题（不是闲聊、语气词、无意义输入）。只返回 true 或 false，不要其他内容。',
  },
  'dialogue.system': {
    name: 'LLM 对话 · 系统提示词',
    desc: 'LLM 驱动对话引擎：角色 + 任务规则 + 对话风格（agentic dialogue）',
    placeholders: ['taskName', 'slotDesc'],
    default: '你是售后客服，正在帮用户办理「{taskName}」。\n需要收集以下信息（字段名: 说明（必填/选填，格式或可选值））：\n{slotDesc}\n对话要求：\n- 回复亲和、简洁、口语化，与真实客服风格一致\n- 用户纠正、插话、提问、一次给多个信息时，先响应用户当前意图，自然推进对话\n- 所有必填信息收集齐后，请用户确认；只有用户明确确认后才视为完成\n- 不要编造用户没提供的信息；不确定时向用户确认\n- 严禁声称已执行未发生的操作：在信息收集齐并经用户确认之前，不得说"已转接/已提交/已登记/已预约/已安排/已办理"等完成性表述；用户要求转接/提交时，回复会先记录并引导确认\n- 只输出要求的 JSON，不要任何其他文字',
  },
  'dialogue.user': {
    name: 'LLM 对话 · 用户模板',
    desc: '每轮对话发给 LLM 的消息模板',
    placeholders: ['taskName', 'slotDesc', 'filledDesc', 'history', 'text'],
    default: '【任务】{taskName}\n【需要收集】{slotDesc}\n【已收集】{filledDesc}\n【对话历史】\n{history}\n【最新输入】{text}\n请输出 JSON：{"slots": {...}, "reply": "...", "ask_confirm": true或false, "question": null或用户提问原文}',
  },
  'dialogue.confirm': {
    name: 'LLM 对话 · 确认清单模板',
    desc: '信息收集齐后展示的确认清单话术',
    placeholders: ['summary'],
    default: '☑ 请确认以下信息：\n{summary}\n回复"确认"提交，或告诉我需要修改的内容。',
  },
  'router.system': {
    name: '意图路由 · 系统提示词',
    desc: '决定用户输入该走哪个通道：继续当前任务 / 发起新任务 / FAQ 知识咨询（规则拿不准时由 LLM 判定）',
    placeholders: ['taskName', 'taskContext'],
    default: '你是客服系统的意图路由器。用户在办理「{taskName}」的过程中说了一句话，请判断这句话属于哪种情况：\n\n1. continue —— 用户在继续办理当前任务（提供/补充/修改任务需要的信息，回答提问，确认或取消等）\n2. new_task —— 用户想办理另一项业务（预约、报修、换表等），或明确不想继续当前任务\n3. faq —— 用户咨询知识性问题（费用、故障原因、操作方法、政策规则等），与当前任务办理无关\n\n判断要点：\n- 提供电话号码、地址、姓名、型号、时间、服务类型等任务字段 → continue\n- 询问费用、价格、原因、怎么处理等 → faq（即使提到与任务相关的词，如"上门换滤芯收费吗"仍是咨询）\n- 表达要办理另一件事 → new_task\n- 寒暄、语气词、无实质内容 → 归入 continue（交给任务引擎引导）\n\n只返回一个词：continue / new_task / faq，不要任何其他内容。',
  },
  'router.user': {
    name: '意图路由 · 用户模板',
    desc: '路由判定时发给 LLM 的用户消息模板',
    placeholders: ['taskName', 'taskContext', 'text'],
    default: '当前任务：{taskName}\n{taskContext}\n用户刚说："{text}"\n请判断应返回：continue / new_task / faq',
  },
  'router.clarify': {
    name: '意图路由 · 澄清话术',
    desc: '路由拿不准（无法区分任务还是咨询）时，追问用户二选一的话术',
    placeholders: ['taskName'],
    default: '抱歉，我没太确定您的需求～您是想办理「{taskName}」业务，还是想咨询其他问题呢？\n请回复对应数字：\n1. 办理「{taskName}」\n2. 咨询其他问题',
  },
}

/** 当前生效的提示词缓存（key -> value，DB 覆盖后与默认值合并） */
let cache = null
let initPromise = null

/** 从数据库加载自定义提示词（幂等，可多次调用） */
export function initPrompts() {
  if (!initPromise) {
    initPromise = (async () => {
      cache = {}
      let db = {}
      try {
        db = await configRepo.getAll()
      } catch (e) {
        console.warn('[PromptRegistry] 配置读取失败，使用默认提示词:', e.message)
      }
      for (const key of Object.keys(PROMPT_DEFS)) {
        cache[key] = db['llm_prompt.' + key] || PROMPT_DEFS[key].default
      }
    })()
  }
  return initPromise
}

/** 取模板并填充占位符（未加载时先用默认值，不阻塞） */
export function get(key, vars = {}) {
  if (!cache) {
    // 未初始化：直接用默认值（启动早期兜底）
    return _fill(PROMPT_DEFS[key]?.default || '', vars)
  }
  return _fill((cache[key] ?? PROMPT_DEFS[key]?.default) || '', vars)
}

/** 返回全部调用点（供管理后台展示与编辑） */
export async function getAll() {
  await initPrompts()
  return Object.entries(PROMPT_DEFS).map(([key, def]) => ({
    key,
    name: def.name,
    desc: def.desc || '',
    placeholders: def.placeholders || [],
    value: cache[key],
    default: def.default,
    isCustom: cache[key] !== def.default,
  }))
}

/**
 * 保存自定义提示词
 * @param {Object} prompts - { key: value }；value 为空字符串/null 表示恢复默认
 */
export async function updatePrompts(prompts) {
  await initPrompts()
  for (const [key, value] of Object.entries(prompts)) {
    if (!PROMPT_DEFS[key]) continue
    if (value === null || value === '' || value === undefined) {
      try { await configRepo.remove(['llm_prompt.' + key]) } catch { /* ignore */ }
      cache[key] = PROMPT_DEFS[key].default
    } else {
      await configRepo.set('llm_prompt.' + key, String(value))
      cache[key] = String(value)
    }
  }
}

/** 填充占位符 {xxx} */
function _fill(template, vars) {
  let t = template
  for (const [k, v] of Object.entries(vars || {})) {
    t = t.split(`{${k}}`).join(v ?? '')
  }
  return t
}

export default { initPrompts, get, getAll, updatePrompts }
